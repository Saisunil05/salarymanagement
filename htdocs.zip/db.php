<?php 
$conn=mysql_connect('localhost','root','','login');
?>