<?php
	header('location:dash_board.html');
?>